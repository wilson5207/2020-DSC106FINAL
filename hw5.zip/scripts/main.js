// Global constants
const DEBUG = true;
const Knife_PRICE = 14.25;
const Fork_PRICE = 9.99;

// Some little helpers
const log = msg => (DEBUG ? console.log(msg) : '');
const select = id => document.getElementById(id);

var continentdata = [
    ['eu', 0],
    ['oc', 1],
    ['af', 2],
    ['as', 3],
    ['na', 4],
	['sa', 5],
	['an', 6]
];

document.getElementById('totalSalesChart').style.visibility ='hidden';
document.getElementById('salesPerMonthChart').style.visibility ='hidden';

Highcharts.getJSON(
	'./data/sales.json', function (salee) {

	let salescontinent = [];
	
	salescontinent.push(salee);

//PIE FUNCTION TO GET THE INPUT DATA!!
	function piesumdata(continentlist) { //ie. salescontinent[0][ContinentName]
		knife_val = 0;
		fork_val = 0;
		for (i in continentlist) {
			knife_val = knife_val + continentlist[i]['Knife']
			fork_val = fork_val + continentlist[i]['Fork']
		}
		
		return [knife_val, fork_val]
	}



//BAR FUNCTION TO GET THE INPUT DATA!!
function barsumdata(continentlist) { //ie. salescontinent[0][ContinentName]
	months = [];
	knife_tot = [];
	fork_tot = [];
	for (i in continentlist) {
		months.push(continentlist[i]['Month']);
		knife_tot.push(continentlist[i]['Knife']);
		fork_tot.push(continentlist[i]['Fork']);
	}
	
	return [knife_tot, fork_tot]
}


//WORLD CONTINENT MAP!!
	mapConfig = Highcharts.mapChart('myMap', {
		chart: {
			map: 'custom/world-continents1'
		},
		
		title: {
			text: ''
		},
		plotOptions: {
			series : {
				cursor: 'pointer',
				events: {
					click: function(a) {
						//UPDATE PIECHART
						input = (a['point']['name'].toUpperCase().replace(/\s/g,''))
						if (input == 'OCEANIA') {input = 'AUSTRALIA'}
						document.getElementById('totalSalesChart').style.visibility ='visible';
						document.getElementById('salesPerMonthChart').style.visibility ='visible';
						chartered.series[0].setData(piesumdata(salescontinent[0][input]));
						ksale = piesumdata(salescontinent[0][input])[0] * Knife_PRICE
						fsale = piesumdata(salescontinent[0][input])[1] * Fork_PRICE;

						//UPDATE BARCHART
						barbar.series[0].setData(barsumdata(salescontinent[0][input])[0])
						barbar.series[1].setData(barsumdata(salescontinent[0][input])[1])

						//UPDATE SCOREBOARD
						document.getElementById('totalSales').textContent = (ksale + fsale).toFixed(2);
						document.getElementById('dingusSold').textContent = piesumdata(salescontinent[0][input])[0];
						document.getElementById('widgetSold').textContent = piesumdata(salescontinent[0][input])[1];
					}
				}
			}
		},
	

		series: [{
			data: continentdata,
			name: '',
			states: {
				hover: {
					color: '#BADA55'
				}
			},
			allowPointSelect: true,
			cursor: 'pointer',
                states: {
                    select: {
                        color: '#a4edba',
                        borderColor: 'black',
                        dashStyle: 'shortdot'
                    }
                },
			dataLabels: {
				enabled: true,
				format: '{point.name}'
			}
		}]
	});


//PIE CHART!!
	chartered = Highcharts.chart('totalSalesChart', {
	chart: {
		type: 'pie'
	},
	title: {
		text: 'Total Sales'
	},
	
	

	plotOptions: {


		pie: {
			
			showInLegend: true,

			cursor: 'pointer',
			dataLabels: {
			enabled: true,
			format: '<b>{point.name}</b>: {point.percentage:.1f} %'
			}
		}
	},

	legend: {
		align: 'left-bottom',
		squareSymbol: false,
		symbolHeight: 20,
		symbolRadius: 0,
		symbolWidth: 50,
	},
	series: [{name: 'Quantity Sold',
		data: [{name: 'Knife',color: 'blue',y: 0,sliced: false,selected: false}, 
		{name: 'Fork',color: 'red',y: 0
		}]
	}]
	});



//BAR CHART!!
	barbar = Highcharts.chart('salesPerMonthChart', {
			chart: {
			type: 'column'
			},
			title: {
			text: 'Monthly Sales'
			},
			xAxis: {
			title: {
				text: 'Month'
			},
			categories: [
				'Jan',
				'Feb',
				'Mar'
			],
			crosshair: true
			},
			yAxis: {
			min: 0,
			title: {
				text: 'Number of units sold'
			}
			},
			tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
				'<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true
			},
			plotOptions: {
			column: {
				pointPadding: 0.2,
				borderWidth: 0
			}
			},
			series: [{
			name: 'Knife',
			data: [0,0,0],
			color: 'blue'
		
			}, {
			name: 'Fork',
			data: [0,0,0],
			color: 'red'
		
			}]
		});

});






//STOCK CHART!!	
    aaa = Highcharts.getJSON(
		'./data/stocks.json', function (stocks) {
			
			let prices = [];
			for (datum of stocks) {
				prices.push([datum['Date'], datum['Adj Close']]);
			}
			
			Highcharts.chart('stockChart', {

			
            chart: {
                zoomType: 'x'
            },
            title: {
                text: 'Dynamic Growth'
            },
            subtitle: {
                text: document.ontouchstart === undefined ?
                    'Stock Prices of K&F Corp. from 2015-Present' : 'Pinch the chart to zoom in'
            },
            xAxis: {
				type: 'datetime',
				labels: { 
					format: '{value:%m/%d/%y}'
				},
				title: {text: 'Date'}
            },
            yAxis: {
                title: {
                    text: 'Adj Close Stock Price'
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [
                            [0, Highcharts.getOptions().colors[0]],
                            [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                        ]
                    },
                    marker: {
                        radius: 2
                    },
                    lineWidth: 1,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    threshold: null
                }
			},
			
			tooltip: {
				pointFormat: '{series.name}: <b>{point.y:.2f}</b><br/>',
				valueSuffix: ' cm',
				shared: true
			},

            series: [{
                type: 'area',
                name: 'Price',
                data: prices
					  
			}]
		
		})
	});
